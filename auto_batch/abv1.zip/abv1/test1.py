from charm.pairing import *
from charm.integer import randomBits

group = pairing("../param/a.param")

bits = 80
N = 256
A = group.random(G1)
delta = [ group.init(ZR, randomBits(bits)) for i in range(N) ]

naive_prod = group.init(G1)

for i in range(N):
    naive_prod *= (A ** delta[i])

print("naive_prod =>", naive_prod)

zr_prod = group.init(ZR, 0)
for i in range(N):
    zr_prod += delta[i] 

result = A ** zr_prod

print("opt_prod =>", result)
