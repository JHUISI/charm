
from batchlang import *


# Rules Engine:
# Each class detects the use of a particular rule. Each application of a rule prodcues a score
# which is based on the number of operations we are able to save that is reducing pairings
# and exponentiations in particular groups. 

# rule types with ordering of 
rule2 = Enum('NoneApplied', 'ExpIntoPairing', 'DistributeExpToPairings')

class DetectRule2:
    def __init__(self, const, vars):
        self.const = const
        self.vars  = vars
        self.score = rule2.NoneApplied
        self.transformStack = [] # grows

    def visit(self, node, data):
        pass

    # find: 'e(g, h)^d_i' transform into ==> 'e(g^d_i, h)' iff g or h is constant
    # move exponent towards the non-constant attribute
    def visit_exp(self, node, data):
        #print("left node =>", node.left.type,"target right node =>", node.right)
        if(Type(node.left) == ops.PAIR):   # and (node.right.attr_index == 'i'): # (node.right.getAttribute() == 'delta'):
            pair_node = node.left
                                  # make cur node the left child of pair node
            # G1 : pair.left, G2 : pair.right
            if not self.isConstInSubtreeT(pair_node.left):
                self.score = rule2.ExpIntoPairing
#                addAsChildNodeToParent(data, pair_node) # move pair node one level up
#                node.left = pair_node.left
#                pair_node.left = node
                #self.rule += "Left := Move '" + str(node.right) + "' exponent into the pairing. "
            
            elif not self.isConstInSubtreeT(pair_node.right):       
                self.score = rule2.ExpIntoPairing
#                
#                addAsChildNodeToParent(data, pair_node) # move pair node one level up                
#                node.left = pair_node.right
#                pair_node.right = node 
                #self.rule += "Right := Move '" + str(node.right) + "' exponent into the pairing. "
            else:
                pass # must handle other cases
            
        # blindly move the right node of prod{} on x^delta regardless    
        elif(Type(node.left) == ops.ON):
            # (prod{} on x) ^ y => prod{} on x^y
            # check whether prod right
            prod_node = node.left
            addAsChildNodeToParent(data, prod_node)
            #print("prod_node right =>", prod_node.right.type)
            # look into x: does x contain a PAIR node?
            pair_node = searchNodeType(prod_node.right, ops.PAIR)
            # if yes: 
            if pair_node:
                # move exp inside the pair node
                # check whether left side is constant
                if not self.isConstInSubtreeT(pair_node.left):
                    #print(" pair right type =>", pair_node.right.type)
                    if Type(pair_node.right) == ops.MUL:
                        _subnodes = []
                        getListNodes(pair_node.right, ops.NONE, _subnodes)
                        if len(_subnodes) > 2: # candidate for expanding
                            self.score = rule2.DistributeExpToPairings
#                            muls = [ BinaryNode(ops.MUL) for i in range(len(_subnodes)-1) ]
#                            for i in range(len(muls)):
#                                muls[i].left = self.createExp(_subnodes[i], BinaryNode.copy(node.right))
#                                if i < len(muls)-1:
#                                    muls[i].right = muls[i+1]
#                                else:
#                                    muls[i].right = self.createExp(_subnodes[i+1], BinaryNode.copy(node.right))
#
#                            pair_node.right = muls[0]
                            #self.rule += "distributed exponent into the pairing: right side. "
                        else:
                            self.setNodeAs(pair_node, 'right', node, 'left')
                            #self.rule += "moved exponent into the pairing: less than 2 mul nodes. "

                    elif Type(pair_node.right) == ops.ATTR:
                        # set pair node left child to node left since we've determined
                        # that the left side of pair node is not a constant
                        self.setNodeAs(pair_node, 'left', node, 'left')
                    else:
                        print("T2: missing case?")

                # check whether right side is constant
                elif not self.isConstInSubtreeT(pair_node.right):
                    # check the type of pair_node : 
                    if Type(pair_node.left) == ops.MUL:
                        pass
                    elif Type(pair_node.left) == ops.ATTR:
                        self.setNodeAs(pair_node, 'left', node, 'left')

            else:
            #    blindly make the exp node the right child of whatever node
                self.setNodeAs(prod_node, 'right', node, 'left')

        elif(Type(node.left) == ops.MUL):
            #print("Consider: node.left.type =>", node.left.type)
            mul_node = node.left
            mul_node.left = self.createExp(mul_node.left, BinaryNode.copy(node.right))
            mul_node.right = self.createExp(mul_node.right, BinaryNode.copy(node.right))
            addAsChildNodeToParent(data, mul_node)            
            #self.rule += " distributed the exp node when applied to a MUL node. "
            # Note: if the operands of the mul are ATTR or PAIR doesn't matter. If the operands are PAIR nodes, PAIR ^ node.right
            # This is OK b/c of preorder visitation, we will apply transformations to the children once we return.
            # The EXP node of the mul children nodes will be visited, so we can apply technique 2 for that node.
        else:
            pass

    def createExp(self, left, right):
        if left.type == ops.EXP: # left => a^b , then => a^(b * c)
            mul = BinaryNode(ops.MUL)
            mul.left = left.right
            mul.right = right
            exp = BinaryNode(ops.EXP)
            exp.left = left.left
            exp.right = mul
        elif left.type in [ops.ATTR, ops.PAIR]: # left: attr ^ right
            exp = BinaryNode(ops.EXP)
            exp.left = left
            exp.right = right
        return exp

    def getNodes(self, tree, parent_type, _list):
        if tree == None: return None
        elif parent_type == ops.MUL:
            if tree.type == ops.ATTR: _list.append(tree)
            elif tree.type == ops.EXP: _list.append(tree)
            elif tree.type == ops.HASH: _list.append(tree)
        
        if tree.left: self.getNodes(tree.left, tree.type, _list)
        if tree.right: self.getNodes(tree.right, tree.type, _list)
        return
        
    def isConstInSubtreeT(self, node): # check whether left or right node is constant  
        if node == None: return None
        if Type(node) == ops.ATTR:
            return self.isConstant(node)
        elif Type(node) == ops.HASH:
            return self.isConstant(node.left)
        result = self.isConstInSubtreeT(node.left)
        if not result: return result
        result = self.isConstInSubtreeT(node.right)
        return result

    def isConstant(self, node):        
        for n in self.consts:
            if n == node.getAttribute(): return True
        return False
        